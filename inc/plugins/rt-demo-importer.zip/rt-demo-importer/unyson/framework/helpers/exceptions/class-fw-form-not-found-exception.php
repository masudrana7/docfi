<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

class FW_Form_Not_Found_Exception extends Exception {

}