<?php

echo fw()->backend->option_type($option['type'])->render($id, $option, $data);
