<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Faktorie_Core;
use \RT_Posts;
use FaktorieTheme;


if ( !class_exists( 'RT_Posts' ) ) {
	return;
}

$post_types = array(
	'faktorie_team'       => array(
		'title'           => __( 'Team Member', 'faktorie-core' ),
		'plural_title'    => __( 'Team', 'faktorie-core' ),
		'menu_icon'       => 'dashicons-businessman',
		'labels_override' => array(
			'menu_name'   => __( 'Team', 'faktorie-core' ),
		),
		'rewrite'         => FaktorieTheme::$options['team_slug'],
		'supports'        => array( 'title', 'thumbnail', 'editor', 'excerpt', 'page-attributes' )
	),
	'faktorie_service'  => array(
		'title'           => __( 'Service', 'faktorie-core' ),
		'plural_title'    => __( 'Services', 'faktorie-core' ),
		'menu_icon'       => 'dashicons-book',
		'rewrite'         => FaktorieTheme::$options['service_slug'],
		'supports'        => array( 'title', 'thumbnail', 'editor', 'excerpt', 'page-attributes' ),
	),
	'faktorie_portfolio'  => array(
		'title'           => __( 'Portfolio', 'faktorie-core' ),
		'plural_title'    => __( 'Portfolios', 'faktorie-core' ),
		'menu_icon'       => 'dashicons-book',
		'rewrite'         => FaktorieTheme::$options['portfolio_slug'],
		'supports'        => array( 'title', 'thumbnail', 'editor', 'excerpt', 'page-attributes' ),
		'taxonomies' 	  => array( 'post_tag' ),
	),
);

$taxonomies = array(
	'faktorie_team_category' => array(
		'title'        => __( 'Team Category', 'faktorie-core' ),
		'plural_title' => __( 'Team Categories', 'faktorie-core' ),
		'post_types'   => 'faktorie_team',
		'rewrite'      => array( 'slug' => FaktorieTheme::$options['team_cat_slug'] ),
	),	
	'faktorie_service_category' => array(
		'title'        => __( 'Service Category', 'faktorie-core' ),
		'plural_title' => __( 'Service Categories', 'faktorie-core' ),
		'post_types'   => 'faktorie_service',
		'rewrite'      => array( 'slug' => FaktorieTheme::$options['service_cat_slug'] ),
	),
	'faktorie_portfolio_category' => array(
		'title'        => __( 'Portfolio Category', 'faktorie-core' ),
		'plural_title' => __( 'Portfolio Categories', 'faktorie-core' ),
		'post_types'   => 'faktorie_portfolio',
		'rewrite'      => array( 'slug' => FaktorieTheme::$options['portfolio_cat_slug'] ),
	),
);


$Posts = RT_Posts::getInstance();
$Posts->add_post_types( $post_types );
$Posts->add_taxonomies( $taxonomies );