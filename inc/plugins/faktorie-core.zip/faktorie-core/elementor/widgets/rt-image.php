<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Faktorie_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

class RT_Image extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'RT Image', 'faktorie-core' );
		$this->rt_base = 'rt-image';
		parent::__construct( $data, $args );
	}

	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'faktorie-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'style',
				'label'   => esc_html__( 'Image Style', 'faktorie-core' ),
				'options' => array(
					'style1' => esc_html__( 'Single Image' , 'faktorie-core' ),
					'style2' => esc_html__( 'Image Shape 01', 'faktorie-core' ),
					'style3' => esc_html__( 'Image Shape 02', 'faktorie-core' ),
					'style4' => esc_html__( 'Image Shape 03', 'faktorie-core' ),
					'style5' => esc_html__( 'Image Shape 04', 'faktorie-core' ),
					'style6' => esc_html__( 'Image Shape 05', 'faktorie-core' ),
				),
				'default' => 'style1',
			),
			array(
				'type' => Controls_Manager::CHOOSE,
				'id'      => 'content_align',
				'mode'    => 'responsive',
				'label'   => esc_html__( 'Alignment', 'faktorie-core' ),
				'options' => array(
					'left' => array(
						'title' => __( 'Left', 'elementor' ),
						'icon' => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => __( 'Center', 'elementor' ),
						'icon' => 'eicon-text-align-center',
					),
					'right' => array(
						'title' => __( 'Right', 'elementor' ),
						'icon' => 'eicon-text-align-right',
					),
				),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				),
			),
			/*image default*/
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'rt_image',
				'label'   => esc_html__( 'Image', 'faktorie-core' ),
				'default' => array(
                    'url' => Utils::get_placeholder_image_src(),
                ),
				'description' => esc_html__( 'Recommended full image', 'faktorie-core' ),
			),
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'rt_image2',
				'label'   => esc_html__( 'Image Shape', 'faktorie-core' ),
				'default' => array(
                    'url' => Utils::get_placeholder_image_src(),
                ),
				'description' => esc_html__( 'Recommended full image', 'faktorie-core' ),
				'condition'   => array( 'style' => array( 'style2', 'style3', 'style6' ) ),
			),
			array(
				'type'    => Group_Control_Image_Size::get_type(),
				'mode'    => 'group',				
				'label'   => esc_html__( 'image size', 'faktorie-core' ),	
				'name' => 'image_size', 
				'separator' => 'none',		
			),
			array(
				'type'    => Group_Control_Css_Filter::get_type(),
				'mode'    => 'group',				
				'label'   => esc_html__( 'Image Blend', 'faktorie-core' ),	
				'name' => 'blend', 
				'selector' => '{{WRAPPER}} img',	
			),	
			array(
				'type'    => Controls_Manager::DIMENSIONS,
				'id'      => 'border_radius',
				'label'   => esc_html__( 'Border Radius', 'faktorie-core' ),
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .rt-image-banner .rt-banner-item img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			),
			array(
				'mode' => 'section_end',
			),
			/*Animation section*/
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_animation_style',
	            'label'   => esc_html__( 'Animation', 'faktorie-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation',
				'label'   => esc_html__( 'Animation', 'faktorie-core' ),
				'options' => array(
					'wow'        => esc_html__( 'On', 'faktorie-core' ),
					'hide'        => esc_html__( 'Off', 'faktorie-core' ),
				),
				'default' => 'hide',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation_effect',
				'label'   => esc_html__( 'Entrance Animation', 'faktorie-core' ),
				'options' => array(
                    'none' => esc_html__( 'none', 'faktorie-core' ),
					'bounce' => esc_html__( 'bounce', 'faktorie-core' ),
					'flash' => esc_html__( 'flash', 'faktorie-core' ),
					'pulse' => esc_html__( 'pulse', 'faktorie-core' ),
					'rubberBand' => esc_html__( 'rubberBand', 'faktorie-core' ),
					'shakeX' => esc_html__( 'shakeX', 'faktorie-core' ),
					'shakeY' => esc_html__( 'shakeY', 'faktorie-core' ),
					'headShake' => esc_html__( 'headShake', 'faktorie-core' ),
					'swing' => esc_html__( 'swing', 'faktorie-core' ),					
					'fadeIn' => esc_html__( 'fadeIn', 'faktorie-core' ),
					'fadeInDown' => esc_html__( 'fadeInDown', 'faktorie-core' ),
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'faktorie-core' ),
					'fadeInRight' => esc_html__( 'fadeInRight', 'faktorie-core' ),
					'fadeInUp' => esc_html__( 'fadeInUp', 'faktorie-core' ),					
					'bounceIn' => esc_html__( 'bounceIn', 'faktorie-core' ),
					'bounceInDown' => esc_html__( 'bounceInDown', 'faktorie-core' ),
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'faktorie-core' ),
					'bounceInRight' => esc_html__( 'bounceInRight', 'faktorie-core' ),
					'bounceInUp' => esc_html__( 'bounceInUp', 'faktorie-core' ),			
					'slideInDown' => esc_html__( 'slideInDown', 'faktorie-core' ),
					'slideInLeft' => esc_html__( 'slideInLeft', 'faktorie-core' ),
					'slideInRight' => esc_html__( 'slideInRight', 'faktorie-core' ),
					'slideInUp' => esc_html__( 'slideInUp', 'faktorie-core' ), 
                ),
				'default' => 'fadeInUp',
				'condition'   => array( 'animation' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'delay',
				'label'   => esc_html__( 'Delay', 'faktorie-core' ),
				'default' => '0.2',
				'condition'   => array( 'animation' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'duration',
				'label'   => esc_html__( 'Duration', 'faktorie-core' ),
				'default' => '1.2',
				'condition'   => array( 'animation' => array( 'wow' ) ),
			),
			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();

		switch ( $data['style'] ) {
			case 'style6':
			$template = 'rt-image-6';
			break;
			case 'style5':
			$template = 'rt-image-5';
			break;
			case 'style4':
			$template = 'rt-image-4';
			break;
			case 'style3':
			$template = 'rt-image-3';
			break;
			case 'style2':			
			$template = 'rt-image-2';
			break;
			default:
			$template = 'rt-image-1';
			break;
		}
	
		return $this->rt_template( $template, $data );
	}
}