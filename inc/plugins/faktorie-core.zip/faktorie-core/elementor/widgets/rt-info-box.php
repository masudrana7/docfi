<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Faktorie_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

class RT_Info_Box extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'RT Info Box', 'faktorie-core' );
		$this->rt_base = 'rt-info-box';
		parent::__construct( $data, $args );
	}

	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'faktorie-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'style',
				'label'   => esc_html__( 'Style', 'faktorie-core' ),
				'options' => array(
					'style1' => esc_html__( 'Info Style 1', 'faktorie-core' ),
					'style2' => esc_html__( 'Info Style 2', 'faktorie-core' ),
					'style3' => esc_html__( 'Info Style 3', 'faktorie-core' ),
					'style4' => esc_html__( 'Info Style 4', 'faktorie-core' ),
					'style5' => esc_html__( 'Info Style 5', 'faktorie-core' ),
					'style6' => esc_html__( 'Info Style 6', 'faktorie-core' ),
					'style7' => esc_html__( 'Info Style 7', 'faktorie-core' ),
					'style8' => esc_html__( 'Info Style 8', 'faktorie-core' ),
					'style9' => esc_html__( 'Info Style 9', 'faktorie-core' ),
				),
				'default' => 'style1',
			),
			array(
				'type' => Controls_Manager::CHOOSE,
				'id'      => 'content_align',
				'mode'	  => 'responsive',
				'label'   => esc_html__( 'Alignment', 'faktorie-core' ),
				'options' => array(
					'left' => array(
						'title' => __( 'Left', 'elementor' ),
						'icon' => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => __( 'Center', 'elementor' ),
						'icon' => 'eicon-text-align-center',
					),
					'right' => array(
						'title' => __( 'Right', 'elementor' ),
						'icon' => 'eicon-text-align-right',
					),
				),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				),
			),
			/*Icon Start*/
			array(					 
			   'type'    => Controls_Manager::CHOOSE,
			   'options' => array(
			     'icon' => array(
			       'title' => esc_html__( 'Left', 'faktorie-core' ),
			       'icon' => 'fa fa-smile',
			     ),
			     'image' => array(
			       'title' => esc_html__( 'Center', 'faktorie-core' ),
			       'icon' => 'fa fa-image',
			     ),		     
			   ),
			   'id'      => 'icontype',
			   'label'   => esc_html__( 'Media Type', 'faktorie-core' ),
			   'default' => 'icon',
			   'label_block' => false,
			   'toggle' => false,
			),
			array(
				'type'    => Controls_Manager::ICONS,
				'id'      => 'icon_class',
				'label'   => esc_html__( 'Icon', 'faktorie-core' ),
				'default' => array(
			      'value' => 'fas fa-smile-wink',
			      'library' => 'fa-solid',
				),	
			  	'condition'   => array('icontype' => array( 'icon' ) ),
			),	
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'icon_image',
				'label'   => esc_html__( 'Image', 'faktorie-core' ),
				'default' => array(
                    'url' => Utils::get_placeholder_image_src(),
                ),
				'description' => esc_html__( 'Recommended full image', 'faktorie-core' ),
				'condition'   => array('icontype' => array( 'image' ) ),
			),
			array(
				'type'    => Group_Control_Image_Size::get_type(),
				'mode'    => 'group',				
				'label'   => esc_html__( 'image size', 'faktorie-core' ),	
				'name' => 'icon_image_size', 
				'separator' => 'none',		
				'condition'   => array('icontype' => array( 'image' ) ),
			),			
			/*Icon end*/
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'title',
				'label'   => esc_html__( 'Title', 'faktorie-core' ),
				'default' => esc_html__( 'Web Development', 'faktorie-core' ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'count_number',
				'label'   => esc_html__( 'Number', 'faktorie-core' ),
				'default' => esc_html__( '01', 'faktorie-core' ),
				'condition'   => array( 'style' => array( 'style7' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'count_year',
				'label'   => esc_html__( 'Year', 'faktorie-core' ),
				'default' => esc_html__( '2017', 'faktorie-core' ),
				'condition'   => array( 'style' => array( 'style9' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXTAREA,
				'id'      => 'content',
				'label'   => esc_html__( 'Content', 'faktorie-core' ),
				'default' => esc_html__( 'It is a longe established factey that  reader will bee Follow readae con page.', 'faktorie-core' ),
				'condition'   => array( 'style!' => array( 'style9' ) ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'button_display',
				'label'       => esc_html__( 'Button Display', 'faktorie-core' ),
				'label_on'    => esc_html__( 'On', 'faktorie-core' ),
				'label_off'   => esc_html__( 'Off', 'faktorie-core' ),
				'default'     => 'no',
				'description' => esc_html__( 'Show or Hide Content. Default: off', 'faktorie-core' ),
				'condition'   => array( 'style' => array( 'style7', 'style8', 'style9' ) ),
			),			
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'buttontext',
				'label'   => esc_html__( 'Button Text', 'faktorie-core' ),
				'default' => esc_html__( 'Visit Website', 'faktorie-core' ),
				'condition'   => array( 'button_display' => array( 'yes' ), 'style' => array( 'style9' ) ),
			),
			array(
				'type'  => Controls_Manager::URL,
				'id'    => 'buttonurl',
				'label' => esc_html__( 'Title Link (Optional)', 'faktorie-core' ),
				'placeholder' => 'https://your-link.com',
			),
			array(
				'mode' => 'section_end',
			),			
			/*Style Option*/
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_box',
				'label'   => esc_html__( 'Box Style', 'faktorie-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'box_bg_color',
				'label'   => esc_html__( 'Box Background Color', 'faktorie-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box .rt-info-item' => 'background-color: {{VALUE}}',
				),
			),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'box_padding',
	            'label'   => __( 'Box Padding', 'faktorie-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-info-box .rt-info-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',                    
	            ),
	            'separator' => 'before',
	        ),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'box_radius',
	            'label'   => __( 'Box Radius', 'faktorie-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-info-box .rt-info-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',                    
	            ),
	        ),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'hover_animation',
				'label'       => esc_html__( 'Hover Animation', 'faktorie-core' ),
				'label_on'    => esc_html__( 'Show', 'faktorie-core' ),
				'label_off'   => esc_html__( 'Hide', 'faktorie-core' ),
				'default'     => 'yes',
				'condition'   => array( 'style' => array( 'style1', 'style3', 'style5' ) ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'active_hover',
				'label'       => esc_html__( 'Active Hover Animation', 'faktorie-core' ),
				'label_on'    => esc_html__( 'Show', 'faktorie-core' ),
				'label_off'   => esc_html__( 'Hide', 'faktorie-core' ),
				'default'     => 'no',
				'condition'   => array( 'hover_animation' => array( 'yes' ), 'style' => array( 'style1', 'style3', 'style5' ) ),
			),
			array(
				'mode' => 'section_end',
			),

			/*Title Option*/
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_title_style',
				'label'   => esc_html__( 'Title Style', 'faktorie-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array(
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'title_typo',
				'label'   => esc_html__( 'Title Typo', 'faktorie-core' ),
				'selector' => '{{WRAPPER}} .rt-info-box .rt-info-item .rt-title',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'title_color',
				'label'   => esc_html__( 'Title Color', 'faktorie-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box .rt-info-item .rt-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .rt-info-box .rt-info-item .rt-title a' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'title_hover_color',
				'label'   => esc_html__( 'Title Hover Color', 'faktorie-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box .rt-info-item .rt-title a:hover' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'title_space',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Title Space', 'faktorie-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 0,
						'max' => 100,
					),
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'selectors' => array( 
					'{{WRAPPER}} .rt-info-box .rt-info-item .rt-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			),
			array(
				'mode' => 'section_end',
			),
			
			// Content style
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_text_title',
				'label'   => esc_html__( 'Content Style', 'faktorie-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),			
			array(
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'content_typo',
				'label'   => esc_html__( 'Content Typo', 'faktorie-core' ),
				'selector' => '{{WRAPPER}} .rt-info-box .rt-info-item .rt-text',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'conent_color',
				'label'   => esc_html__( 'Content Color', 'faktorie-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box .rt-info-item .rt-text' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'content_space',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Content Space', 'faktorie-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 0,
						'max' => 100,
					),
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'selectors' => array( 
					'{{WRAPPER}} .rt-info-box .rt-info-item .rt-text' => 'margin-top: {{SIZE}}{{UNIT}};',
				),
			),	
			array(
				'mode' => 'section_end',
			),			
			// Icon style
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_icon',
				'label'   => esc_html__( 'Icon Style', 'faktorie-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),			
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'icon_size',
				'label'   => esc_html__( 'Icon Size', 'faktorie-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box .rt-info-item .rt-icon' => 'font-size: {{VALUE}}px',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'icon_bg_color',
				'label'   => esc_html__( 'Icon BG Color', 'faktorie-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box .rt-info-item .rt-icon' => 'background-color: {{VALUE}}',
				),
				'condition'   => array( 'style' => array( 'style1', 'style3', 'style5' ) ),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'icon_color',
				'label'   => esc_html__( 'Icon Color', 'faktorie-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box .rt-info-item .rt-icon' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'icon_hover_color',
				'label'   => esc_html__( 'Icon Hover Color', 'faktorie-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-info-box .rt-info-item:hover .rt-icon' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'icon_space',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Icon Space', 'faktorie-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 0,
						'max' => 100,
					),
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'selectors' => array( 
					'{{WRAPPER}} .rt-info-box .rt-info-item .rt-media' => 'margin-right: {{SIZE}}{{UNIT}};',
				),
			),		
			array(
				'mode' => 'section_end',
			),
			// Animation style
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_animation_style',
	            'label'   => esc_html__( 'Animation', 'faktorie-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation',
				'label'   => esc_html__( 'Animation', 'faktorie-core' ),
				'options' => array(
					'wow'        => esc_html__( 'On', 'faktorie-core' ),
					'hide'        => esc_html__( 'Off', 'faktorie-core' ),
				),
				'default' => 'hide',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation_effect',
				'label'   => esc_html__( 'Entrance Animation', 'faktorie-core' ),
				'options' => array(
                    'none' => esc_html__( 'none', 'faktorie-core' ),
					'bounce' => esc_html__( 'bounce', 'faktorie-core' ),
					'flash' => esc_html__( 'flash', 'faktorie-core' ),
					'pulse' => esc_html__( 'pulse', 'faktorie-core' ),
					'rubberBand' => esc_html__( 'rubberBand', 'faktorie-core' ),
					'shakeX' => esc_html__( 'shakeX', 'faktorie-core' ),
					'shakeY' => esc_html__( 'shakeY', 'faktorie-core' ),
					'headShake' => esc_html__( 'headShake', 'faktorie-core' ),
					'swing' => esc_html__( 'swing', 'faktorie-core' ),					
					'fadeIn' => esc_html__( 'fadeIn', 'faktorie-core' ),
					'fadeInDown' => esc_html__( 'fadeInDown', 'faktorie-core' ),
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'faktorie-core' ),
					'fadeInRight' => esc_html__( 'fadeInRight', 'faktorie-core' ),
					'fadeInUp' => esc_html__( 'fadeInUp', 'faktorie-core' ),					
					'bounceIn' => esc_html__( 'bounceIn', 'faktorie-core' ),
					'bounceInDown' => esc_html__( 'bounceInDown', 'faktorie-core' ),
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'faktorie-core' ),
					'bounceInRight' => esc_html__( 'bounceInRight', 'faktorie-core' ),
					'bounceInUp' => esc_html__( 'bounceInUp', 'faktorie-core' ),			
					'slideInDown' => esc_html__( 'slideInDown', 'faktorie-core' ),
					'slideInLeft' => esc_html__( 'slideInLeft', 'faktorie-core' ),
					'slideInRight' => esc_html__( 'slideInRight', 'faktorie-core' ),
					'slideInUp' => esc_html__( 'slideInUp', 'faktorie-core' ), 
                ),
				'default' => 'fadeInUp',
				'condition'   => array('animation' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'delay',
				'label'   => esc_html__( 'Delay', 'faktorie-core' ),
				'default' => '0.2',
				'condition'   => array( 'animation' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'duration',
				'label'   => esc_html__( 'Duration', 'faktorie-core' ),
				'default' => '1.2',
				'condition'   => array( 'animation' => array( 'wow' ) ),
			),
			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();

		switch ( $data['style'] ) {
			case 'style9':
			$template = 'rt-info-box-9';
			break;
			case 'style8':
			$template = 'rt-info-box-8';
			break;
			case 'style7':
			$template = 'rt-info-box-7';
			break;
			case 'style6':
			$template = 'rt-info-box-6';
			break;
			case 'style5':
			$template = 'rt-info-box-5';
			break;
			case 'style4':
			$template = 'rt-info-box-4';
			break;
			case 'style3':
			$template = 'rt-info-box-3';
			break;
			case 'style2':
			$template = 'rt-info-box-2';
			break;
			default:
			$template = 'rt-info-box-1';
			break;
		}

		return $this->rt_template( $template, $data );
	}
}