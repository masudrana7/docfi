<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

add_action( 'widgets_init', 'faktorie_widgets_init' );
function faktorie_widgets_init() {
	// Register Custom Widgets
	register_widget( 'FaktorieTheme_About_Widget' );
	register_widget( 'FaktorieTheme_Address_Widget' );
	register_widget( 'FaktorieTheme_Social_Widget' );
	register_widget( 'FaktorieTheme_Post_Box' );
	register_widget( 'FaktorieTheme_Post_Tab' );
	register_widget( 'FaktorieTheme_Feature_Post' );
	register_widget( 'FaktorieTheme_Product_Box' );
	register_widget( 'FaktorieTheme_Category_Widget' );
	register_widget( 'FaktorieTheme_Download_Widget' );
	register_widget( 'FaktorieTheme_Contact_Widget' );
}