<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Faktorie_Core;

use FaktorieTheme;
use FaktorieTheme_Helper;
use \RT_Postmeta;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( !class_exists( 'RT_Postmeta' ) ) {
	return;
}

$Postmeta = RT_Postmeta::getInstance();

$prefix = FAKTORIE_CORE_CPT_PREFIX;

/*-------------------------------------
#. Layout Settings
---------------------------------------*/
$nav_menus = wp_get_nav_menus( array( 'fields' => 'id=>name' ) );
$nav_menus = array( 'default' => __( 'Default', 'faktorie-core' ) ) + $nav_menus;
$sidebars  = array( 'default' => __( 'Default', 'faktorie-core' ) ) + FaktorieTheme_Helper::custom_sidebar_fields();

$Postmeta->add_meta_box( "{$prefix}_page_settings", __( 'Layout Settings', 'faktorie-core' ), array( 'page', 'post', 'faktorie_team', 'faktorie_portfolio', 'faktorie_service', 'product' ), '', '', 'high', array(
	'fields' => array(
	
		"{$prefix}_layout_settings" => array(
			'label'   => __( 'Layouts', 'faktorie-core' ),
			'type'    => 'group',
			'value'  => array(	
			
				"{$prefix}_layout" => array(
					'label'   => __( 'Layout', 'faktorie-core' ),
					'type'    => 'select',
					'options' => array(
						'default'       => __( 'Default', 'faktorie-core' ),
						'full-width'    => __( 'Full Width', 'faktorie-core' ),
						'left-sidebar'  => __( 'Left Sidebar', 'faktorie-core' ),
						'right-sidebar' => __( 'Right Sidebar', 'faktorie-core' ),
					),
					'default'  => 'default',
				),		
				'faktorie_sidebar' => array(
					'label'    => __( 'Custom Sidebar', 'faktorie-core' ),
					'type'     => 'select',
					'options'  => $sidebars,
					'default'  => 'default',
				),
				"{$prefix}_page_menu" => array(
					'label'    => __( 'Main Menu', 'faktorie-core' ),
					'type'     => 'select',
					'options'  => $nav_menus,
					'default'  => 'default',
				),
				"{$prefix}_top_bar" => array(
					'label' 	  => __( 'Top Bar', 'faktorie-core' ),
					'type'  	  => 'select',
					'options' => array(
						'default' => __( 'Default', 'faktorie-core' ),
						'on'      => __( 'Enabled', 'faktorie-core' ),
						'off'     => __( 'Disabled', 'faktorie-core' ),
					),
					'default'  	  => 'default',
				),
				"{$prefix}_top_bar_style" => array(
					'label' 	=> __( 'Top Bar Layout', 'faktorie-core' ),
					'type'  	=> 'select',
					'options'	=> array(
						'default' => __( 'Default', 'faktorie-core' ),
						'1'       => __( 'Layout 1', 'faktorie-core' ),
						'2'       => __( 'Layout 2', 'faktorie-core' ),
						'3'       => __( 'Layout 3', 'faktorie-core' ),
						'4'       => __( 'Layout 4', 'faktorie-core' ),
					),
					'default'   => 'default',
				),
				"{$prefix}_header_opt" => array(
					'label' 	  => __( 'Header On/Off', 'faktorie-core' ),
					'type'  	  => 'select',
					'options' => array(
						'default' => __( 'Default', 'faktorie-core' ),
						'on'      => __( 'Enabled', 'faktorie-core' ),
						'off'     => __( 'Disabled', 'faktorie-core' ),
					),
					'default'  	  => 'default',
				),
				"{$prefix}_tr_header" => array(
					'label'    	  => __( 'Transparent Header', 'faktorie-core' ),
					'type'     	  => 'select',
					'options'  	  => array(
						'default' => __( 'Default', 'faktorie-core' ),
						'on'      => __( 'Enabled', 'faktorie-core' ),
						'off'     => __( 'Disabled', 'faktorie-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_header" => array(
					'label'   => __( 'Header Layout', 'faktorie-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'faktorie-core' ),
						'1'       => __( 'Layout 1', 'faktorie-core' ),
						'2'       => __( 'Layout 2', 'faktorie-core' ),
						'3'       => __( 'Layout 3', 'faktorie-core' ),
						'4'       => __( 'Layout 4', 'faktorie-core' ),
						'5'       => __( 'Layout 5', 'faktorie-core' ),
						'6'       => __( 'Layout 6', 'faktorie-core' ),
						'7'       => __( 'Layout 7', 'faktorie-core' ),
						'8'       => __( 'Layout 8', 'faktorie-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_footer" => array(
					'label'   => __( 'Footer Layout', 'faktorie-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'faktorie-core' ),
						'1'       => __( 'Layout 1', 'faktorie-core' ),
						'2'       => __( 'Layout 2', 'faktorie-core' ),
						'3'       => __( 'Layout 3', 'faktorie-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_footer_area" => array(
					'label' 	  => __( 'Footer Area', 'faktorie-core' ),
					'type'  	  => 'select',
					'options' => array(
						'default' => __( 'Default', 'faktorie-core' ),
						'on'      => __( 'Enabled', 'faktorie-core' ),
						'off'     => __( 'Disabled', 'faktorie-core' ),
					),
					'default'  	  => 'default',
				),
				"{$prefix}_copyright_area" => array(
					'label' 	  => __( 'Copyright Area', 'faktorie-core' ),
					'type'  	  => 'select',
					'options' => array(
						'default' => __( 'Default', 'faktorie-core' ),
						'on'      => __( 'Enabled', 'faktorie-core' ),
						'off'     => __( 'Disabled', 'faktorie-core' ),
					),
					'default'  	  => 'default',
				),
				"{$prefix}_top_padding" => array(
					'label'   => __( 'Content Padding Top', 'faktorie-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'faktorie-core' ),
						'0px'     => __( '0px', 'faktorie-core' ),
						'10px'    => __( '10px', 'faktorie-core' ),
						'20px'    => __( '20px', 'faktorie-core' ),
						'30px'    => __( '30px', 'faktorie-core' ),
						'40px'    => __( '40px', 'faktorie-core' ),
						'50px'    => __( '50px', 'faktorie-core' ),
						'60px'    => __( '60px', 'faktorie-core' ),
						'70px'    => __( '70px', 'faktorie-core' ),
						'80px'    => __( '80px', 'faktorie-core' ),
						'90px'    => __( '90px', 'faktorie-core' ),
						'100px'   => __( '100px', 'faktorie-core' ),
						'110px'   => __( '110px', 'faktorie-core' ),
						'120px'   => __( '120px', 'faktorie-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_bottom_padding" => array(
					'label'   => __( 'Content Padding Bottom', 'faktorie-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'faktorie-core' ),
						'0px'     => __( '0px', 'faktorie-core' ),
						'10px'    => __( '10px', 'faktorie-core' ),
						'20px'    => __( '20px', 'faktorie-core' ),
						'30px'    => __( '30px', 'faktorie-core' ),
						'40px'    => __( '40px', 'faktorie-core' ),
						'50px'    => __( '50px', 'faktorie-core' ),
						'60px'    => __( '60px', 'faktorie-core' ),
						'70px'    => __( '70px', 'faktorie-core' ),
						'80px'    => __( '80px', 'faktorie-core' ),
						'90px'    => __( '90px', 'faktorie-core' ),
						'100px'   => __( '100px', 'faktorie-core' ),
						'110px'   => __( '110px', 'faktorie-core' ),
						'120px'   => __( '120px', 'faktorie-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_banner" => array(
					'label'   => __( 'Banner', 'faktorie-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'faktorie-core' ),
						'on'	  => __( 'Enable', 'faktorie-core' ),
						'off'	  => __( 'Disable', 'faktorie-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_breadcrumb" => array(
					'label'   => __( 'Breadcrumb', 'faktorie-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'faktorie-core' ),
						'on'      => __( 'Enable', 'faktorie-core' ),
						'off'	  => __( 'Disable', 'faktorie-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_banner_type" => array(
					'label'   => __( 'Banner Background Type', 'faktorie-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'faktorie-core' ),
						'bgimg'   => __( 'Background Image', 'faktorie-core' ),
						'bgcolor' => __( 'Background Color', 'faktorie-core' ),
					),
					'default' => 'default',
				),
				"{$prefix}_banner_bgimg" => array(
					'label' => __( 'Banner Background Image', 'faktorie-core' ),
					'type'  => 'image',
					'desc'  => __( 'If not selected, default will be used', 'faktorie-core' ),
				),
				"{$prefix}_banner_bgcolor" => array(
					'label' => __( 'Banner Background Color', 'faktorie-core' ),
					'type'  => 'color_picker',
					'desc'  => __( 'If not selected, default will be used', 'faktorie-core' ),
				),		
				"{$prefix}_page_bgimg" => array(
					'label' => __( 'Page/Post Background Image', 'faktorie-core' ),
					'type'  => 'image',
					'desc'  => __( 'If not selected, default will be used', 'faktorie-core' ),
				),
				"{$prefix}_page_bgcolor" => array(
					'label' => __( 'Page/Post Background Color', 'faktorie-core' ),
					'type'  => 'color_picker',
					'desc'  => __( 'If not selected, default will be used', 'faktorie-core' ),
				),
			)
		)
	),
) );

/*-------------------------------------
#. Single Post Gallery
---------------------------------------*/
$Postmeta->add_meta_box( 'faktorie_post_info', __( 'Post Info', 'faktorie-core' ), array( 'post' ), '', '', 'high', array(
	'fields' => array(
		"faktorie_youtube_link" => array(
			'label'   => __( 'Youtube Link', 'faktorie-core' ),
			'type'    => 'text',
			'default'  => '',
			'desc'  => __( 'Only work for the video post format', 'faktorie-core' ),
		),
		'faktorie_post_gallery' => array(
			'label' => __( 'Post Gallery', 'faktorie-core' ),
			'type'  => 'gallery',
			'desc'  => __( 'Only work for the gallery post format', 'faktorie-core' ),
		),
	),
) );

/*-------------------------------------
#. Team
---------------------------------------*/
$Postmeta->add_meta_box( 'faktorie_team_settings', __( 'Team Member Settings', 'faktorie-core' ), array( 'faktorie_team' ), '', '', 'high', array(
	'fields' => array(
		'faktorie_team_position' => array(
			'label' => __( 'Position', 'faktorie-core' ),
			'type'  => 'text',
		),
		'faktorie_team_website' => array(
			'label' => __( 'Website', 'faktorie-core' ),
			'type'  => 'text',
		),
		'faktorie_team_email' => array(
			'label' => __( 'Email', 'faktorie-core' ),
			'type'  => 'text',
		),
		'faktorie_team_phone' => array(
			'label' => __( 'Phone', 'faktorie-core' ),
			'type'  => 'text',
		),
		'faktorie_team_address' => array(
			'label' => __( 'Address', 'faktorie-core' ),
			'type'  => 'text',
		),
		'faktorie_team_socials_header' => array(
			'label' => __( 'Socials', 'faktorie-core' ),
			'type'  => 'header',
			'desc'  => __( 'Enter your social links here', 'faktorie-core' ),
		),
		'faktorie_team_socials' => array(
			'type'  => 'group',
			'value'  => FaktorieTheme_Helper::team_socials()
		),
	)
) );

$Postmeta->add_meta_box( 'faktorie_team_skills', __( 'Team Member Skills', 'faktorie-core' ), array( 'faktorie_team' ), '', '', 'high', array(
	'fields' => array(
		'faktorie_team_skill_info' => array(
			'label' => __( 'Skill Info', 'faktorie-core' ),
			'type'  => 'textarea',
		),
		'faktorie_team_skill' => array(
			'type'  => 'repeater',
			'button' => __( 'Add New Skill', 'faktorie-core' ),
			'value'  => array(
				'skill_name' => array(
					'label' => __( 'Skill Name', 'faktorie-core' ),
					'type'  => 'text',
					'desc'  => __( 'eg. Marketing', 'faktorie-core' ),
				),
				'skill_value' => array(
					'label' => __( 'Skill Percentage (%)', 'faktorie-core' ),
					'type'  => 'text',
					'desc'  => __( 'eg. 75', 'faktorie-core' ),
				),
				'skill_color' => array(
					'label' => __( 'Skill Color', 'faktorie-core' ),
					'type'  => 'color_picker',
					'desc'  => __( 'If not selected, primary color will be used', 'faktorie-core' ),
				),
			)
		),
	)
) );
$Postmeta->add_meta_box( 'faktorie_team_contact', __( 'Team Member Contact', 'faktorie-core' ), array( 'faktorie_team' ), '', '', 'high', array(
	'fields' => array(
		'faktorie_team_contact_form' => array(
			'label' => __( 'Contct Shortcode', 'faktorie-core' ),
			'type'  => 'text',
		),
	)
) );

/*-------------------------------------
#. Portfolio
---------------------------------------*/
$Postmeta->add_meta_box( 'faktorie_portfolio_info', __( 'Portfolio Project Information', 'faktorie-core' ), array( 'faktorie_portfolio' ), '', '', 'high', array(
	'fields' => array(
		'faktorie_project_title' => array(
			'label' => __( 'Project Title', 'faktorie-core' ),
			'type'  => 'text',
		),
		'faktorie_project_text' => array(
			'label' => __( 'Project Text', 'faktorie-core' ),
			'type'  => 'text',
		),
		'faktorie_project_client' => array(
			'label' => __( 'Project Client', 'faktorie-core' ),
			'type'  => 'text',
		),
		'faktorie_project_start' => array(
			'label' => __( 'Project Start', 'faktorie-core' ),
			'type'  => 'text',
		),
		'faktorie_project_end' => array(
			'label' => __( 'Project End', 'faktorie-core' ),
			'type'  => 'text',
		),
		'faktorie_project_web' => array(
			'label' => __( 'Project Web', 'faktorie-core' ),
			'type'  => 'text',
			'default'  => '',
		),				
		'faktorie_project_rating' => array(
			'label' => __( 'Select the Rating', 'faktorie-core' ),
			'type'  => 'select',
			'options' => array(
				'-1' => __( 'Default', 'faktorie-core' ),
				'1'    => '1',
				'2'    => '2',
				'3'    => '3',
				'4'    => '4',
				'5'    => '5'
				),
			'default'  => '-1',
		),
	)
) );

/*-------------------------------------
#. Service
---------------------------------------*/
$Postmeta->add_meta_box( 'faktorie_service_style_box', __( 'Service style', 'faktorie-core' ), array( 'faktorie_service' ), '', '', 'high', array(
	'fields' => array(
		"faktorie_service_style" => array(
			'label'   => __( 'Service Template', 'faktorie-core' ),
			'type'    => 'select',
			'options' => array(
				'default'  => __( 'Default', 'faktorie-core' ),
				'style1'  => __( 'Style 1', 'faktorie-core' ),
				'style2'  => __( 'Style 2', 'faktorie-core' ),
			),
			'default'  => 'default',
		),
	),
) );

$Postmeta->add_meta_box( 'faktorie_service_media', __( 'Service Icon image', 'faktorie-core' ),array( "faktorie_service" ),'',
		'side',
		'default', array(
		'fields' => array(
			"faktorie_service_icon" => array(
			  'label' => __( 'Service Icon', 'faktorie-core' ),
			  'type'  => 'icon_select',
			  'desc'  => __( "Choose a Icon for your service", 'faktorie-core' ),
			  'options' => FaktorieTheme_Helper::get_icons(),
			),
		)
) );

/*-------------------------------------
#. WooCommerce
---------------------------------------*/
$Postmeta->add_meta_box( 'faktorie_woo_product', __( 'Product Background', 'faktorie-core' ), array( 'product' ), '', '', 'high', array(
	'fields' => array(
		'faktorie_product_bgc' => array(
			'label' => __( 'Product Background Color', 'faktorie-core' ),
			'type'  => 'color_picker',
		),
	)
) );